from django.urls import path, re_path 
from data_app import views as data_views

app_name = "data_app"

urlpatterns = [
    path('landing_page/', data_views.landing_page, name="landing_page"),
    path('about_us/', data_views.about_us, name='about_us'),
    path('portfolio/', data_views.portfolio, name='portfolio'),
    # path('blogs/', data_views.blogs, name='blogs'),
    # path('contact/', data_views.contact, name='contact'),
    # path('blog_details/', data_views.blog_details, name='blog_details'),
]
    
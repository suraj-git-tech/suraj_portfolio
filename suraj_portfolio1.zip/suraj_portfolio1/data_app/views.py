from django.shortcuts import render

# Create your views here.
def landing_page(request):
    return render(request,'data_app/index.html')


def about_us(request):
    return render(request,'data_app/about-us.html')

def portfolio(request):
    return render(request,'data_app/portfolio.html')

# def blogs(request):
#     return render(request,'data_app/blog.html')

# def contact(request):
#     return render(request,'data_app/contact.html')
    
    
# def blog_details(request):
#     return render(request,'data_app/blog_details.html')